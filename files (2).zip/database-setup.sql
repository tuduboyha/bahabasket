-- ============================================================
-- LOCAL BAZAAR HUB — Complete Database Setup
-- Version: 1.0
-- Run this in phpMyAdmin → SQL tab
-- ============================================================

SET FOREIGN_KEY_CHECKS = 0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+05:30";

-- ══════════════════════════════════════
-- TABLE 1: USERS
-- ══════════════════════════════════════
CREATE TABLE IF NOT EXISTS `users` (
  `id`           INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`         VARCHAR(100) NOT NULL,
  `phone`        VARCHAR(15) NOT NULL,
  `email`        VARCHAR(150) DEFAULT NULL,
  `password`     VARCHAR(255) DEFAULT NULL,
  `city`         VARCHAR(80) DEFAULT NULL,
  `role`         ENUM('buyer','seller','admin') NOT NULL DEFAULT 'buyer',
  `avatar`       VARCHAR(255) DEFAULT NULL,
  `is_verified`  TINYINT(1) NOT NULL DEFAULT 0,
  `is_active`    TINYINT(1) NOT NULL DEFAULT 1,
  `created_at`   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`   DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_phone` (`phone`),
  KEY `idx_role` (`role`),
  KEY `idx_city` (`city`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ══════════════════════════════════════
-- TABLE 2: OTP LOGS
-- ══════════════════════════════════════
CREATE TABLE IF NOT EXISTS `otp_logs` (
  `id`         INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `phone`      VARCHAR(15) NOT NULL,
  `otp`        VARCHAR(6) NOT NULL,
  `purpose`    ENUM('register','login','reset') NOT NULL DEFAULT 'login',
  `is_used`    TINYINT(1) NOT NULL DEFAULT 0,
  `expires_at` DATETIME NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_phone` (`phone`),
  KEY `idx_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ══════════════════════════════════════
-- TABLE 3: CATEGORIES
-- ══════════════════════════════════════
CREATE TABLE IF NOT EXISTS `categories` (
  `id`         INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`       VARCHAR(100) NOT NULL,
  `slug`       VARCHAR(100) NOT NULL,
  `icon`       VARCHAR(10) DEFAULT NULL,
  `parent_id`  INT(11) UNSIGNED DEFAULT NULL,
  `sort_order` INT(5) NOT NULL DEFAULT 0,
  `is_active`  TINYINT(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_slug` (`slug`),
  KEY `idx_parent` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ══════════════════════════════════════
-- TABLE 4: SHOPS
-- ══════════════════════════════════════
CREATE TABLE IF NOT EXISTS `shops` (
  `id`            INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`       INT(11) UNSIGNED NOT NULL,
  `name`          VARCHAR(150) NOT NULL,
  `slug`          VARCHAR(150) NOT NULL,
  `tagline`       VARCHAR(255) DEFAULT NULL,
  `description`   TEXT DEFAULT NULL,
  `category_id`   INT(11) UNSIGNED DEFAULT NULL,
  `whatsapp`      VARCHAR(15) NOT NULL,
  `phone`         VARCHAR(15) DEFAULT NULL,
  `email`         VARCHAR(150) DEFAULT NULL,
  `address`       TEXT DEFAULT NULL,
  `city`          VARCHAR(80) DEFAULT NULL,
  `area`          VARCHAR(100) DEFAULT NULL,
  `pincode`       VARCHAR(10) DEFAULT NULL,
  `logo`          VARCHAR(255) DEFAULT NULL,
  `cover_image`   VARCHAR(255) DEFAULT NULL,
  `plan`          ENUM('free','growth','premium') NOT NULL DEFAULT 'free',
  `plan_expiry`   DATE DEFAULT NULL,
  `rating`        DECIMAL(2,1) NOT NULL DEFAULT 0.0,
  `total_reviews` INT(11) NOT NULL DEFAULT 0,
  `is_verified`   TINYINT(1) NOT NULL DEFAULT 0,
  `is_featured`   TINYINT(1) NOT NULL DEFAULT 0,
  `is_active`     TINYINT(1) NOT NULL DEFAULT 1,
  `status`        ENUM('pending','active','suspended') NOT NULL DEFAULT 'pending',
  `created_at`    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_slug` (`slug`),
  KEY `idx_user` (`user_id`),
  KEY `idx_category` (`category_id`),
  KEY `idx_city` (`city`),
  KEY `idx_status` (`status`),
  KEY `idx_plan` (`plan`),
  CONSTRAINT `fk_shop_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ══════════════════════════════════════
-- TABLE 5: PRODUCTS
-- ══════════════════════════════════════
CREATE TABLE IF NOT EXISTS `products` (
  `id`           INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `shop_id`      INT(11) UNSIGNED NOT NULL,
  `category_id`  INT(11) UNSIGNED DEFAULT NULL,
  `name`         VARCHAR(200) NOT NULL,
  `slug`         VARCHAR(200) NOT NULL,
  `description`  TEXT DEFAULT NULL,
  `price`        DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `mrp`          DECIMAL(10,2) DEFAULT NULL,
  `sizes`        VARCHAR(255) DEFAULT NULL COMMENT 'JSON array e.g. ["S","M","L"]',
  `colors`       VARCHAR(255) DEFAULT NULL COMMENT 'JSON array e.g. ["Red","Blue"]',
  `images`       TEXT DEFAULT NULL COMMENT 'JSON array of image paths',
  `is_featured`  TINYINT(1) NOT NULL DEFAULT 0,
  `is_active`    TINYINT(1) NOT NULL DEFAULT 1,
  `status`       ENUM('live','draft','flagged') NOT NULL DEFAULT 'live',
  `views`        INT(11) NOT NULL DEFAULT 0,
  `wa_clicks`    INT(11) NOT NULL DEFAULT 0,
  `created_at`   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`   DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_shop` (`shop_id`),
  KEY `idx_category` (`category_id`),
  KEY `idx_status` (`status`),
  FULLTEXT KEY `ft_product_search` (`name`,`description`),
  CONSTRAINT `fk_product_shop` FOREIGN KEY (`shop_id`) REFERENCES `shops` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ══════════════════════════════════════
-- TABLE 6: SHOP GALLERY
-- ══════════════════════════════════════
CREATE TABLE IF NOT EXISTS `shop_gallery` (
  `id`          INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `shop_id`     INT(11) UNSIGNED NOT NULL,
  `image_path`  VARCHAR(255) NOT NULL,
  `caption`     VARCHAR(255) DEFAULT NULL,
  `sort_order`  INT(5) NOT NULL DEFAULT 0,
  `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_shop` (`shop_id`),
  CONSTRAINT `fk_gallery_shop` FOREIGN KEY (`shop_id`) REFERENCES `shops` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ══════════════════════════════════════
-- TABLE 7: REVIEWS
-- ══════════════════════════════════════
CREATE TABLE IF NOT EXISTS `reviews` (
  `id`             INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `shop_id`        INT(11) UNSIGNED NOT NULL,
  `user_id`        INT(11) UNSIGNED DEFAULT NULL,
  `reviewer_name`  VARCHAR(100) DEFAULT NULL,
  `rating`         TINYINT(1) NOT NULL,
  `title`          VARCHAR(200) DEFAULT NULL,
  `body`           TEXT DEFAULT NULL,
  `is_verified`    TINYINT(1) NOT NULL DEFAULT 0,
  `is_approved`    TINYINT(1) NOT NULL DEFAULT 0,
  `created_at`     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_shop` (`shop_id`),
  KEY `idx_user` (`user_id`),
  CONSTRAINT `fk_review_shop` FOREIGN KEY (`shop_id`) REFERENCES `shops` (`id`) ON DELETE CASCADE,
  CONSTRAINT `chk_rating` CHECK (`rating` BETWEEN 1 AND 5)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ══════════════════════════════════════
-- TABLE 8: WHATSAPP INQUIRIES
-- ══════════════════════════════════════
CREATE TABLE IF NOT EXISTS `wa_inquiries` (
  `id`          INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `shop_id`     INT(11) UNSIGNED NOT NULL,
  `product_id`  INT(11) UNSIGNED DEFAULT NULL,
  `user_id`     INT(11) UNSIGNED DEFAULT NULL,
  `source`      VARCHAR(50) DEFAULT 'unknown',
  `ip_address`  VARCHAR(45) DEFAULT NULL,
  `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_shop` (`shop_id`),
  KEY `idx_product` (`product_id`),
  KEY `idx_date` (`created_at`),
  CONSTRAINT `fk_inq_shop` FOREIGN KEY (`shop_id`) REFERENCES `shops` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ══════════════════════════════════════
-- TABLE 9: OFFERS
-- ══════════════════════════════════════
CREATE TABLE IF NOT EXISTS `offers` (
  `id`          INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title`       VARCHAR(200) NOT NULL,
  `description` TEXT DEFAULT NULL,
  `category_id` INT(11) UNSIGNED DEFAULT NULL,
  `discount`    VARCHAR(50) DEFAULT NULL,
  `image`       VARCHAR(255) DEFAULT NULL,
  `starts_at`   DATETIME DEFAULT NULL,
  `expires_at`  DATETIME DEFAULT NULL,
  `is_active`   TINYINT(1) NOT NULL DEFAULT 1,
  `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_active` (`is_active`),
  KEY `idx_expiry` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ══════════════════════════════════════
-- TABLE 10: COUPONS
-- ══════════════════════════════════════
CREATE TABLE IF NOT EXISTS `coupons` (
  `id`          INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `code`        VARCHAR(30) NOT NULL,
  `type`        ENUM('percentage','flat') NOT NULL DEFAULT 'percentage',
  `value`       DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `min_order`   DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `max_uses`    INT(11) NOT NULL DEFAULT 100,
  `used_count`  INT(11) NOT NULL DEFAULT 0,
  `expires_at`  DATETIME DEFAULT NULL,
  `is_active`   TINYINT(1) NOT NULL DEFAULT 1,
  `created_at`  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_code` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ══════════════════════════════════════
-- TABLE 11: MEMBERSHIP PLANS
-- ══════════════════════════════════════
CREATE TABLE IF NOT EXISTS `membership_plans` (
  `id`           INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`         VARCHAR(50) NOT NULL,
  `slug`         VARCHAR(50) NOT NULL,
  `price`        DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `duration`     INT(11) NOT NULL DEFAULT 30 COMMENT 'Duration in days',
  `max_products` INT(11) NOT NULL DEFAULT 10,
  `features`     TEXT DEFAULT NULL COMMENT 'JSON array of features',
  `is_active`    TINYINT(1) NOT NULL DEFAULT 1,
  `sort_order`   INT(5) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ══════════════════════════════════════
-- TABLE 12: PAYMENTS
-- ══════════════════════════════════════
CREATE TABLE IF NOT EXISTS `payments` (
  `id`             INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `shop_id`        INT(11) UNSIGNED NOT NULL,
  `plan_id`        INT(11) UNSIGNED NOT NULL,
  `amount`         DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `currency`       VARCHAR(5) NOT NULL DEFAULT 'INR',
  `gateway`        VARCHAR(30) DEFAULT 'manual',
  `gateway_txn_id` VARCHAR(100) DEFAULT NULL,
  `status`         ENUM('pending','paid','failed','refunded') NOT NULL DEFAULT 'pending',
  `paid_at`        DATETIME DEFAULT NULL,
  `created_at`     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_shop` (`shop_id`),
  KEY `idx_status` (`status`),
  KEY `idx_date` (`created_at`),
  CONSTRAINT `fk_payment_shop` FOREIGN KEY (`shop_id`) REFERENCES `shops` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ══════════════════════════════════════
-- TABLE 13: BANNERS
-- ══════════════════════════════════════
CREATE TABLE IF NOT EXISTS `banners` (
  `id`         INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title`      VARCHAR(150) DEFAULT NULL,
  `image`      VARCHAR(255) NOT NULL,
  `link_url`   VARCHAR(255) DEFAULT NULL,
  `position`   VARCHAR(50) DEFAULT 'hero',
  `sort_order` INT(5) NOT NULL DEFAULT 0,
  `is_active`  TINYINT(1) NOT NULL DEFAULT 1,
  `starts_at`  DATETIME DEFAULT NULL,
  `expires_at` DATETIME DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_position` (`position`),
  KEY `idx_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ══════════════════════════════════════
-- TABLE 14: CONTACT MESSAGES
-- ══════════════════════════════════════
CREATE TABLE IF NOT EXISTS `contact_messages` (
  `id`         INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`       VARCHAR(100) DEFAULT NULL,
  `email`      VARCHAR(150) DEFAULT NULL,
  `phone`      VARCHAR(15) DEFAULT NULL,
  `subject`    VARCHAR(200) DEFAULT NULL,
  `message`    TEXT DEFAULT NULL,
  `status`     ENUM('new','read','replied') NOT NULL DEFAULT 'new',
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ══════════════════════════════════════
-- TABLE 15: WISHLISTS
-- ══════════════════════════════════════
CREATE TABLE IF NOT EXISTS `wishlists` (
  `id`         INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`    INT(11) UNSIGNED NOT NULL,
  `product_id` INT(11) UNSIGNED DEFAULT NULL,
  `shop_id`    INT(11) UNSIGNED DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  CONSTRAINT `fk_wish_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ══════════════════════════════════════
-- TABLE 16: USER SESSIONS
-- ══════════════════════════════════════
CREATE TABLE IF NOT EXISTS `user_sessions` (
  `id`         VARCHAR(64) NOT NULL,
  `user_id`    INT(11) UNSIGNED NOT NULL,
  `ip_address` VARCHAR(45) DEFAULT NULL,
  `user_agent` VARCHAR(255) DEFAULT NULL,
  `expires_at` DATETIME NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_expires` (`expires_at`),
  CONSTRAINT `fk_session_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ══════════════════════════════════════
-- TABLE 17: SUPPORT TICKETS
-- ══════════════════════════════════════
CREATE TABLE IF NOT EXISTS `support_tickets` (
  `id`         INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`    INT(11) UNSIGNED DEFAULT NULL,
  `name`       VARCHAR(100) DEFAULT NULL,
  `email`      VARCHAR(150) DEFAULT NULL,
  `subject`    VARCHAR(200) NOT NULL,
  `message`    TEXT NOT NULL,
  `priority`   ENUM('normal','high','urgent') NOT NULL DEFAULT 'normal',
  `status`     ENUM('new','in_progress','resolved','closed') NOT NULL DEFAULT 'new',
  `admin_note` TEXT DEFAULT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_status` (`status`),
  KEY `idx_priority` (`priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ══════════════════════════════════════
-- TABLE 18: SHOP WORKING HOURS
-- ══════════════════════════════════════
CREATE TABLE IF NOT EXISTS `shop_hours` (
  `id`         INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `shop_id`    INT(11) UNSIGNED NOT NULL,
  `day`        TINYINT(1) NOT NULL COMMENT '0=Sun, 1=Mon ... 6=Sat',
  `open_time`  TIME DEFAULT NULL,
  `close_time` TIME DEFAULT NULL,
  `is_closed`  TINYINT(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_shop_day` (`shop_id`,`day`),
  CONSTRAINT `fk_hours_shop` FOREIGN KEY (`shop_id`) REFERENCES `shops` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ══════════════════════════════════════
-- TABLE 19: NOTIFICATIONS
-- ══════════════════════════════════════
CREATE TABLE IF NOT EXISTS `notifications` (
  `id`         INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`    INT(11) UNSIGNED DEFAULT NULL COMMENT 'NULL = broadcast to all',
  `title`      VARCHAR(200) NOT NULL,
  `message`    TEXT NOT NULL,
  `type`       VARCHAR(50) DEFAULT 'info',
  `link`       VARCHAR(255) DEFAULT NULL,
  `is_read`    TINYINT(1) NOT NULL DEFAULT 0,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_read` (`is_read`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ══════════════════════════════════════
-- TABLE 20: SETTINGS
-- ══════════════════════════════════════
CREATE TABLE IF NOT EXISTS `settings` (
  `id`          INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `setting_key` VARCHAR(100) NOT NULL,
  `setting_val` TEXT DEFAULT NULL,
  `updated_at`  DATETIME DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- ══════════════════════════════════════
-- DEFAULT DATA INSERT
-- ══════════════════════════════════════

-- Categories
INSERT INTO `categories` (`name`, `slug`, `icon`, `sort_order`) VALUES
('Men Fashion',         'men-fashion',         '👔', 1),
('Women Fashion',       'women-fashion',       '👗', 2),
('Kids Wear',           'kids-wear',           '🧒', 3),
('Electronics',         'electronics',         '📱', 4),
('Mobile Accessories',  'mobile-accessories',  '🎧', 5),
('Footwear',            'footwear',            '👟', 6),
('Jewellery',           'jewellery',           '💍', 7),
('Home Decor',          'home-decor',          '🏠', 8),
('Sports & Fitness',    'sports-fitness',      '⚽', 9),
('Books & Stationery',  'books-stationery',    '📚', 10);

-- Membership Plans
INSERT INTO `membership_plans` (`name`, `slug`, `price`, `duration`, `max_products`, `features`, `sort_order`) VALUES
('Free',    'free',    0.00,  30,  10,  '["10 Products","WhatsApp Button","Basic Profile","Standard Listing"]', 1),
('Growth',  'growth',  499.00, 30, 100, '["100 Products","Featured Listing","Analytics Dashboard","Priority Support","Offer Badges"]', 2),
('Premium', 'premium', 999.00, 30, 999, '["Unlimited Products","Top Featured","Banner Ads","Advanced Analytics","Dedicated Support","Custom Badge"]', 3);

-- Admin user (password: Admin@2024)
INSERT INTO `users` (`name`, `phone`, `email`, `password`, `role`, `is_verified`, `is_active`) VALUES
('Admin User', '9876543210', 'admin@localbazaarhub.in',
 '$2y$12$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', 1, 1);

-- Default Settings
INSERT INTO `settings` (`setting_key`, `setting_val`) VALUES
('site_name',           'Local Bazaar Hub'),
('site_tagline',        'Apna Dukaan, Digital Duniya'),
('admin_whatsapp',      '+919876543210'),
('admin_email',         'admin@localbazaarhub.in'),
('default_city',        'Indore'),
('currency',            'INR'),
('currency_symbol',     '₹'),
('free_plan_products',  '10'),
('auto_approve_shops',  '0'),
('maintenance_mode',    '0'),
('registration_open',   '1'),
('razorpay_key',        ''),
('razorpay_secret',     ''),
('msg91_key',           ''),
('msg91_template',      ''),
('smtp_host',           ''),
('smtp_user',           ''),
('smtp_pass',           ''),
('smtp_port',           '587'),
('google_analytics',    ''),
('facebook_pixel',      '');
