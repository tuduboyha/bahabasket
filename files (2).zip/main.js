// ============================================================
// LOCAL BAZAAR HUB — Main JavaScript
// File: assets/js/main.js
// ============================================================

// ── Mobile menu toggle ────────────────────────────────────
function toggleMobileMenu() {
  const menu = document.getElementById('mobileMenu');
  if (menu) menu.classList.toggle('open');
}

// ── Back to top button ────────────────────────────────────
window.addEventListener('scroll', () => {
  const btn = document.getElementById('backToTop');
  if (btn) btn.classList.toggle('visible', window.scrollY > 400);
});

// ── Flash message auto-hide ───────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  const flash = document.getElementById('flashMsg');
  if (flash) {
    setTimeout(() => {
      flash.style.opacity = '0';
      flash.style.transition = 'opacity .5s';
      setTimeout(() => flash.remove(), 500);
    }, 4000);
  }

  // Animate elements on scroll
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.animationPlayState = 'running';
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });

  document.querySelectorAll('.shop-card, .product-card, .cat-card').forEach(el => {
    el.style.animationPlayState = 'paused';
    observer.observe(el);
  });
});

// ── WA Inquiry tracker ────────────────────────────────────
function trackInquiry(shopId, productId, source) {
  if (!shopId) return;
  const siteUrl = document.querySelector('meta[name="site-url"]')?.content || '';
  navigator.sendBeacon(
    siteUrl + '/api/inquiries/track.php',
    new URLSearchParams({
      shop_id    : shopId,
      product_id : productId || '',
      source     : source || 'unknown',
    })
  );
}

// ── Lazy load images ──────────────────────────────────────
if ('IntersectionObserver' in window) {
  const imgObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const img = entry.target;
        if (img.dataset.src) {
          img.src = img.dataset.src;
          img.removeAttribute('data-src');
          imgObserver.unobserve(img);
        }
      }
    });
  });
  document.querySelectorAll('img[data-src]').forEach(img => imgObserver.observe(img));
}

// ── Smooth scroll for anchor links ───────────────────────
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function(e) {
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      e.preventDefault();
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
});
